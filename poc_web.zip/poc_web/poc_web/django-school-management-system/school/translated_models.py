# Import necessary modules
from ast import Sub
from django.db import models
import datetime
from ckeditor_uploader.fields import RichTextUploadingField
from django.contrib.auth.models import User
from datetime import date
from django.utils import timezone

# Create your models here.

# Define a Python class named 'Status' that represents a database table using Django models.
class Status(models.Model):
    status_id = models.AutoField(primary_key=True)  # Define a field 'status_id' as an AutoField, which serves as an automatically incrementing primary key.
    status_description = models.CharField(max_length=100)  # Define a field 'status_description' as a character field with a maximum length of 100 characters.

    def __str__(self):
        return self.status_description

# Define a Python class named 'Grade' that represents a database table using Django models.
class Grade(models.Model):
    grade_id = models.AutoField(primary_key=True)  # Define a field 'grade_id' as an AutoField, which serves as an automatically incrementing primary key.
    grade_name = models.CharField(max_length=100)  # Define a field 'grade_name' as a character field with a maximum length of 100 characters.
    grade_tit = models.CharField(max_length=200, null=True)

    def __str__(self):
        return self.grade_name

# Define a Python class named 'AcademicYear' that represents a database table using Django models.
class AcademicYear(models.Model):
    academic_year = models.CharField(max_length=20)
    year_tit = models.CharField(max_length=200)

    def __str__(self):
        return self.academic_year

# Define a Python class named 'Class' that represents a database table using Django models.
class Class(models.Model):
    grade = models.ForeignKey(Grade, max_length=3, on_delete=models.PROTECT)
    class_id = models.AutoField(primary_key=True)
    academic_year = models.ForeignKey(AcademicYear, max_length=20, on_delete=models.PROTECT)
    class_name = models.CharField(max_length=10, null=True)
    class_code = models.CharField(max_length=10, null=True)
    number_of_students = models.IntegerField(null=True)
    teacher = models.TextField(null=True)

    def __str__(self):
        return self.class_name

# Define a Python class named 'Student' that represents a database table using Django models.
class Student(models.Model):
    class_id = models.ForeignKey(Class, on_delete=models.CASCADE)
    student_id = models.CharField(max_length=11, unique=True)
    name = models.CharField(max_length=100, null=True)
    gender = models.CharField(max_length=10, null=True,
        choices=[
            ('Male', 'Male'),
            ('Female', 'Female')
        ])
    phone_number = models.CharField(max_length=100, null=True)
    address = models.CharField(max_length=200, unique=False, null=True)
    image = models.ImageField(upload_to="school/images",
                              default="school/images/default.png", null=True)
    father_name = models.CharField(max_length=100, null=True)
    mother_name = models.CharField(max_length=100, null=True)

    def __str__(self):
        return self.student_id

# Define a Python class named 'Subject' that represents a database table using Django models.
class Subject(models.Model):
    subject_id = models.AutoField(primary_key=True)
    subject_name = models.CharField(max_length=100)
    subject_title = models.CharField(max_length=200, null=True)

    def __str__(self):
        return self.subject_name

# Define a Python class named 'Result' that represents a database table using Django models.
class Result(models.Model):
    student_id = models.ForeignKey(Student, on_delete=models.CASCADE)
    semester = models.CharField(max_length=10, null=True,
        choices=[
            ('Semester 1', 'Semester 1'),
            ('Semester 2', 'Semester 2'),
        ])
    exam_type = models.CharField(max_length=20, null=True,
        choices=[
            ('Regular', 'Regular'),
            ('Midterm', 'Midterm'),
            ('Final', 'Final'),
        ])
    subject = models.ForeignKey(Subject, on_delete=models.CASCADE)
    exam_number = models.IntegerField(null=True,
        choices=[
            (1, '1'),
            (2, '2'),
            (3, '3'),
        ])
    exam_score = models.FloatField(null=True)
    exam_date = models.DateField(null=True)

    def __str__(self):
        return '{}'.format(self.student_id)

# Define a Python class named 'EntranceExam' that represents a database table using Django models.
class EntranceExam(models.Model):
    exam_code = models.CharField(max_length=10, unique=True)
    name = models.CharField(max_length=100, null=True)
    math_score = models.FloatField(blank=True, null=True)
    literature_score = models.FloatField(blank=True, null=True)
    physics_score = models.FloatField(blank=True, null=True)
    chemistry_score = models.FloatField(blank=True, null=True)
    history_score = models.FloatField(blank=True, null=True)
    geography_score = models.FloatField(blank=True, null=True)
    informatics_score = models.FloatField(blank=True, null=True)
    foreign_language_score = models.FloatField(blank=True, null=True)
    biology_score = models.FloatField(blank=True, null=True)

    def __str__(self):
        return self.exam_code

# Define a Python class named 'Library' that represents a database table using Django models.
class Library(models.Model):
    library_id = models.AutoField(primary_key=True)
    library_name = models.CharField(max_length=100)
    library_title = models.CharField(max_length=200, null=True)
    full_name = models.CharField(max_length=200, null=True)

    def __str__(self):
        return self.library_name

# Define a Python class named 'Document' that represents a database table using Django models.
class Document(models.Model):
    document_id = models.AutoField(primary_key=True)
    library_id = models.ForeignKey(Library, on_delete=models.CASCADE)
    subject_id = models.ForeignKey(Subject, null=True, on_delete=models.CASCADE)
    grade_id = models.ForeignKey(Grade, null=True, on_delete=models.CASCADE)
    status_id = models.ForeignKey(Status, on_delete=models.CASCADE)
    document_name = models.CharField(max_length=200)
    document_title = models.CharField(max_length=200, null=True)
    summary = models.TextField()
    pdf = models.CharField(max_length=200, null=True)
    pdf_size = models.IntegerField(null=True)
    original_file = models.CharField(max_length=200, null=True)
    original_file_size = models.IntegerField(null=True)
    upload_date = models.DateTimeField(default=timezone.now)

    def __str__(self):
        return self.document_name

# Define a Python class named 'Category' that represents a database table using Django models.
class Category(models.Model):
    category_id = models.AutoField(primary_key=True)
    category_name = models.CharField(max_length=200)
    image = models.ImageField(upload_to="school/images",
                              default="school/images/default.png", null=True)
    description = models.TextField()

    def __str__(self):
        return self.category_name

# Define a Python class named 'Blog' that represents a database table using Django models.
class Blog(models.Model):
    category_id = models.ForeignKey(Category, on_delete=models.CASCADE)
    subcategory_id = models.IntegerField(null=True)
    status_id = models.ForeignKey(Status, on_delete=models.CASCADE)
    title = models.CharField(max_length=200)
    blog_title = models.CharField(max_length=200, null=True)
    summary = models.TextField()
    content = RichTextUploadingField(blank=True, null=True)
    submission_date = models.DateTimeField(default=timezone.now)
    publication_date = models.DateTimeField(default=timezone.now)
    expiration_date = models.DateTimeField(default=timezone.now)
    image = models.ImageField(upload_to="school/images",
                              default="school/images/default.png", null=True)
    source = models.CharField(max_length=200, null=True)
    submitter = models.CharField(max_length=200,  null=True)
    viewed = models.IntegerField(default=0)
    comments = models.IntegerField(default=0)

    def __str__(self):
        return self.title

# Define a Python class named 'ExecutiveBoard' that represents a database table using Django models.
class ExecutiveBoard(models.Model):
    board_id = models.AutoField(primary_key=True)
    board_name = models.CharField(max_length=200)
    email = models.EmailField(max_length=200)
    description = RichTextUploadingField()
    image = models.ImageField(upload_to="school/images",
                              default="school/images/default.png", null=True)

    def __str__(self):
        return self.board_name

# Define a Python class named 'StudentUnion' that represents a database table using Django models.
class StudentUnion(models.Model):
    student_union_id = models.AutoField(primary_key=True)
    student_union_name = models.CharField(max_length=200)
    email = models.EmailField(max_length=200)
    description = RichTextUploadingField()
    image = models.ImageField(upload_to="school/images",
                              default="school/images/default.png", null=True)

    def __str__(self):
        return self.student_union_name

# Define a Python class named 'Department' that represents a database table using Django models.
class Department(models.Model):
    department_id = models.AutoField(primary_key=True)
    category_id = models.ForeignKey(Category, null=True, on_delete=models.CASCADE)
    department_name = models.CharField(max_length=200)
    department_title = models.CharField(max_length=200, null=True)
    email = models.EmailField(max_length=200)
    description = RichTextUploadingField()
    introduction = RichTextUploadingField(default='')
    image = models.ImageField(upload_to="school/images",
                              default="school/images/default.png", null=True)

    def __str__(self):
        return self.department_name

# Define a Python class named 'City' that represents a database table using Django models.
class City(models.Model):
    city_name = models.CharField(max_length=200)

    def __str__(self):
        return self.city_name

# Define a Python class named 'UserProfileInfo' that represents a database table using Django models.
class UserProfileInfo(models.Model):
    user = models.OneToOneField(User, on_delete=models.PROTECT)
    full_name = models.CharField(max_length=100, unique=False, default='')
    address = models.CharField(max_length=250, unique=False)
    phone = models.CharField(max_length=20)
    image = models.ImageField(upload_to="school/images/", default="school/images/ptnkavatar.png", null=True)

    def __str__(self):
        return self.user.username

# Define a Python class named 'Contact' that represents a database table using Django models.
class Contact(models.Model):
    name = models.CharField(max_length=150)
    email = models.EmailField()
    phone_number = models.CharField(max_length=20, null=True)
    subject = models.CharField(max_length=264)
    message = models.TextField()

    def __str__(self):
        return self.name + ", " + self.subject

# Define a Python class named 'Admission' that represents a database table using Django models.
class Admission(models.Model):
    name = models.CharField(max_length=150)
    email = models.EmailField()
    phone_number = models.CharField(max_length=20, null=True)
    school = models.CharField(max_length=264)
    classroom = models.CharField(max_length=264, choices=[
    ('Non-Specialized', 'Non-Specialized'),
    ('Math', 'Math'),
    ('Literature', 'Literature'),
    ('Physics', 'Physics'),
    ('Chemistry', 'Chemistry'),
    ('Biology', 'Biology'),
    ('Informatics', 'Informatics'),
    ('English', 'English')
])

    def __str__(self):
        return self.name + ", " + self.email

# Define a Python class named 'Comment' that represents a database table using Django models.
class Comment(models.Model):
    name = models.CharField(max_length=150)
    email = models.EmailField(max_length=100, blank=True, default='')
    content = RichTextUploadingField(max_length=500)
    blog = models.ForeignKey(Blog, on_delete=models.CASCADE,null=True)
    created = models.DateTimeField(default=timezone.now)
    avatar = models.ImageField(upload_to="school/images/", default="school/images/ptnkavatar.png", null=True)
    is_user = models.BooleanField(default=False)
    total_likes = models.IntegerField(default=0)
    total_dislikes = models.IntegerField(default=0)

    class Meta:
        ordering = ('-created',)

    def __str__(self):
        return 'Comment by {} - {} - {}'.format(self.name, self.blog, self.is_user)

# Define a Python class named 'Like' that represents a database table using Django models.
class Like(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, null=True)
    blog = models.ForeignKey(Blog, on_delete=models.CASCADE, null=True)
    comment = models.ForeignKey(Comment, on_delete=models.CASCADE, null=True)
    created = models.DateTimeField(default=timezone.now)
    is_like = models.BooleanField(default=True)

    class Meta:
        ordering = ('-created',)

    def __str__(self):
        return self.is_like
