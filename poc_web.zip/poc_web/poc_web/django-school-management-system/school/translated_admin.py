# Import necessary modules
from django.contrib import admin
from datetime import datetime
from school.models import *
from django.db.models import F, Count
from . import models
from import_export.admin import ImportExportMixin
from django.utils import timezone

# Register your models here.

# Function to update the 'ngay_gui_bai' field for selected items to the current date
def change_submission_date(modeladmin, request, queryset):
    queryset.update(submission_date=timezone.now())

# Function to increment the 'viewed' field by 1 for selected items
def increment_view_count(modeladmin, request, queryset):
    queryset.update(viewed=F('viewed') + 1)

# Function to update the 'si_so' field of classes based on the number of students
def update_class_size(modeladmin, request, queryset):
    students = models.Student.objects.values('class_id', 'class_id__class_name', 'class_id__grade_id').annotate(
        total=Count('class_id')).order_by('class_id')
    for student_info in students:
        queryset.filter(class_id=student_info['class_id']).update(class_size=student_info['total'])

# Admin class for the 'Result' model
class ResultAdmin(ImportExportMixin, admin.ModelAdmin):
    list_display = ('student', 'semester', 'exam_type', 'exam_number', 'subject', 'exam_score')
    list_filter = ('semester', 'subject', 'exam_type', )

# Admin class for the 'Blog' model
class BlogAdmin(ImportExportMixin, admin.ModelAdmin):
    list_display = ('title', 'status', 'submission_date', 'viewed', 'comments')
    list_filter = ('submission_date', 'viewed', 'comments', )
    search_fields = ('title__contains', )
    actions = [change_submission_date, increment_view_count]

# Admin class for the 'Class' model
class ClassAdmin(ImportExportMixin, admin.ModelAdmin):
    list_display = ('class_name', 'academic_year', 'class_size', 'teacher')
    actions = [update_class_size]

# Admin class for the 'Student' model
class StudentAdmin(ImportExportMixin, admin.ModelAdmin):
    list_display = ('student_id', 'class_id', 'name', 'gender')
    list_filter = ('class_id', 'gender', )

# Admin class for the 'Comment' model
class CommentAdmin(admin.ModelAdmin):
    list_filter = ('blog', 'created', )

# Admin class for the 'Document' model
class DocumentAdmin(ImportExportMixin, admin.ModelAdmin):
    list_display = ('grade', 'subject', 'document_name')
    list_filter = ('grade', 'subject', 'document_name', )

# Admin class for the 'Like' model
class LikeAdmin(ImportExportMixin, admin.ModelAdmin):
    list_display = ('created', 'blog', 'comment', 'is_like', 'user')
    list_filter = ('created', 'blog', 'is_like',  )

# Register Django models with the admin site
admin.site.register(Grade)
admin.site.register(Class, ClassAdmin)
admin.site.register(Student, StudentAdmin)
admin.site.register(AcademicYear)
admin.site.register(Subject)
admin.site.register(Document, DocumentAdmin)
admin.site.register(Library)
admin.site.register(StudentUnion)
admin.site.register(ExecutiveBoard)
admin.site.register(Department)
admin.site.register(Status)
admin.site.register(Category)
admin.site.register(Blog, BlogAdmin)
admin.site.register(City)
admin.site.register(UserProfileInfo)
admin.site.register(Contact)
admin.site.register(Result, ResultAdmin)
admin.site.register(EntranceExam)
admin.site.register(Admission)
admin.site.register(Comment, CommentAdmin)
admin.site.register(Like, LikeAdmin)

# Customize the admin site header
admin.site.site_header = 'PTNK Admin'
