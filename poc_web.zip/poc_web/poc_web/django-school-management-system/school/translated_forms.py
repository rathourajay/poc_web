from django import forms
from . import models
from django.core.validators import RegexValidator

# Choices for the 'classroom' field
CLASS_CHOICES = [
    ('KC', 'Non-Specialized'),
    ('CT', 'Mathematics Major'),
    ('CV', 'Literature Major'),
    ('CL', 'Physics Major'),
    ('CH', 'Chemistry Major'),
    ('CS', 'Biology Major'),
    ('CTin', 'Information Technology Major'),
    ('CA', 'English Major')
]

# Regular expression validator for phone numbers
phone_validator = RegexValidator(
    r"((^(\+84|84|0|0084){1})(3|5|7|8|9))+([0-9]{8})$",
    "Phone numbers must be in the format (xxx)xxxxxxxxx or 0xxxxxxxxx!")

# Contact Form
class ContactForm(forms.ModelForm):
    name = forms.CharField(max_length=150, label='Name', widget=forms.TextInput(attrs={
        'placeholder': '...', 'class': 'form-control fh5co_contact_text_box'}))
    phone_number = forms.CharField(max_length=20, label='Phone', validators=[phone_validator], widget=forms.TextInput(
        attrs={'placeholder': '...',
                'class': 'form-control fh5co_contact_text_box',
                'pattern': '((^(\+84|84|0|0084){1})(3|5|7|8|9))+([0-9]{8})$',
                'title': 'Phone numbers must be in the format (xxx)xxxxxxxxx or 0xxxxxxxxx'}))
    email = forms.EmailField(label='Email', widget=forms.TextInput(
        attrs={'placeholder': '...', 'class': 'form-control fh5co_contact_text_box'}))
    subject = forms.CharField(label='Subject', widget=forms.TextInput(
        attrs={'placeholder': '...', 'class': 'form-control fh5co_contact_text_box'}))
    message = forms.CharField(widget=forms.Textarea(
        attrs={'placeholder': '...', 'class': 'form-control fh5co_contacts_message'}))

    class Meta:
        model = models.Contact
        fields = '__all__'

# Admission Form
class AdmissionForm(forms.ModelForm):
    name = forms.CharField(max_length=150, label='Name', widget=forms.TextInput(attrs={
        'placeholder': 'Full Name', 'class': 'form-control fh5co_contact_text_box'}))
    phone_number = forms.CharField(max_length=20, label='Phone', validators=[phone_validator], widget=forms.TextInput(
        attrs={'placeholder': 'Phone Number',
                'class': 'form-control fh5co_contact_text_box',
                'pattern': '((^(\+84|84|0|0084){1})(3|5|7|8|9))+([0-9]{8})$',
                'title': 'Phone numbers must be in the format (xxx)xxxxxxxxx or 0xxxxxxxxx'}))
    email = forms.EmailField(label='Email', widget=forms.TextInput(
        attrs={'placeholder': 'Email', 'class': 'form-control fh5co_contact_text_box'}))
    school = forms.CharField(label='School', widget=forms.TextInput(
        attrs={'placeholder': 'School Name', 'class': 'form-control fh5co_contact_text_box'}))
    classroom = forms.CharField(label='Classroom', widget=forms.Select(choices=CLASS_CHOICES, attrs={
        'placeholder': 'Class', 'class': 'form-control fh5co_contact_text_box'}))

    class Meta:
        model = models.Admission
        fields = '__all__'

# User Registration Form
class UserRegistrationForm(forms.ModelForm):
    password = forms.CharField(max_length=150, label='Password', widget=forms.PasswordInput(attrs={'placeholder': 'Password', 'pattern': '(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d]{8,}$',
               'title': 'Minimum 8 characters, at least 1 letter and 1 number', 'class': 'form-control fh5co_contact_text_box'}))
    confirm = forms.CharField(max_length=150, label='Confirm Password', widget=forms.PasswordInput(attrs={'placeholder': 'Confirm Password', 'class': 'form-control fh5co_contact_text_box'}))
    email = forms.EmailField(widget=forms.TextInput(attrs={'placeholder': 'Email', 'class': 'form-control fh5co_contact_text_box'}))
    username = forms.CharField(
        max_length=50, widget=forms.TextInput(attrs={'placeholder': 'Username', 'pattern': '^[A-Za-z][A-Za-z0-9_]{6,12}$', 'title': 'Minimum 6 characters, maximum 12 characters, and no special characters', 'class': 'form-control fh5co_contact_text_box'}))
    
    class Meta:
        model = models.User
        fields = ('username', 'email', 'password')

# User Profile Information Form
class UserProfileInfoForm(forms.ModelForm):
    fullname = forms.CharField(
        max_length=500, widget=forms.TextInput(attrs={'placeholder': 'Full Name', 'class': 'form-control fh5co_contact_text_box'}))
    address = forms.CharField(max_length=500, widget=forms.TextInput(attrs={'placeholder': 'Address', 'class': 'form-control fh5co_contact_text_box'}))
    phone = forms.CharField(max_length=20, label='Phone', widget=forms.TextInput(
        attrs={'placeholder': 'Phone Number', 'pattern': '((^(\+84|84|0|0084){1})(3|5|7|8|9))+([0-9]{8})$',
               'title': 'Phone numbers must be in the format (xxx)xxxxxxxxx or 0xxxxxxxxx', 'class': 'form-control fh5co_contact_text_box'}))
    image = forms.ImageField(required=False)
    
    class Meta:
        model = models.UserProfileInfo
        exclude = ('user', )

# Update User Form
class UpdateUserForm(forms.ModelForm):
    password = forms.CharField(max_length=150, label='Password', widget=forms.PasswordInput(attrs={'placeholder': 'Password', 'pattern': '(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d]{8,}$',
               'title': 'Minimum 8 characters, at least 1 letter and 1 number', 'class': 'form-control fh5co_contact_text_box'}))
    confirm = forms.CharField(max_length=150, label='Confirm Password', widget=forms.PasswordInput(attrs={'placeholder': 'Confirm Password', 'class': 'form-control fh5co_contact_text_box'}))
    email = forms.EmailField(widget=forms.TextInput(attrs={'placeholder': 'Email', 'class': 'form-control fh5co_contact_text_box'}))

    class Meta:
        model = models.User
        fields = ('password', 'email')

# Update User Profile Information Form
class UpdateUserProfileInfoForm(forms.ModelForm):
    fullname = forms.CharField(
        max_length=500, widget=forms.TextInput(attrs={'placeholder': 'Full Name', 'class': 'form-control fh5co_contact_text_box'}))
    address = forms.CharField(max_length=500, widget=forms.TextInput(attrs={'placeholder': 'Address', 'class': 'form-control fh5co_contact_text_box'}))
    phone = forms.CharField(max_length=20, label='Phone', widget=forms.TextInput(
        attrs={'placeholder': 'Phone Number', 'pattern': '((^(\+84|84|0|0084){1})(3|5|7|8|9))+([0-9]{8})$',
               'title': 'Phone numbers must be in the format (xxx)xxxxxxxxx or 0xxxxxxxxx', 'class': 'form-control fh5co_contact_text_box'}))
    image = forms.ImageField(required=False)

    class Meta:
        model = models.UserProfileInfo
        exclude = ('user', )

# Comment Form
class CommentForm(forms.ModelForm):
    name = forms.CharField(required=False, max_length=150, widget=forms.TextInput(attrs={
        'placeholder': 'Name', 'class': 'form-control fh5co_contact_text_box'}))
    email = forms.EmailField(max_length=100, widget=forms.TextInput(
        attrs={'placeholder': 'Email', 'class': 'form-control fh5co_contact_text_box'}))
    content = forms.CharField(max_length=500, widget=forms.Textarea(
        attrs={'placeholder': '...', 'class': 'form-control fh5co_contacts_message'}))
    class Meta:
        model = models.Comment
        fields = ('name', 'email', 'content')
